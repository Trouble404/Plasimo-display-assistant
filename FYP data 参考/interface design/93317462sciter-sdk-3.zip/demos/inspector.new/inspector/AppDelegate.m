//
//  AppDelegate.m
//  inspector
//
//  Created by Andrew Fedoniouk on 2015-07-31.
//  Copyright (c) 2015 Andrew Fedoniouk. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

@end

install node.js
in command line do:
0. cd {this folder}
1. npm install
2. node quote.js
3. run client.htm in sciter.
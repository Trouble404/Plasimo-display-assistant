//
//  SciterAppDelegate.m
//  layered
//
//  Created by andrew on 2014-04-17.
//  Copyright (c) 2014 andrew fedoniouk. All rights reserved.
//

#import "SciterAppDelegate.h"

@implementation SciterAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end

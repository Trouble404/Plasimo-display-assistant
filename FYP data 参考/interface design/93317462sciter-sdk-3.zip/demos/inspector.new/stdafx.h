#ifndef __that_sad_stdafx_defined__
#define __that_sad_stdafx_defined__
#include "sciter-x.h"
#endif

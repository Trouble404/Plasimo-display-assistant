#!/bin/sh

echo "compiling!"
../../bin.osx/packfolder res resources.cpp -v sciter_resources
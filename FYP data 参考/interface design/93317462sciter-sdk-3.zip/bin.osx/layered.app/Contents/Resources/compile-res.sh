#!/bin/sh

echo "compiling!"
../../bin.osx/respack ./resources.cpp ./res/ layered
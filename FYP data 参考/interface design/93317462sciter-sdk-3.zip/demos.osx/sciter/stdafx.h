//
//  stdafx.h
//  sciter
//
//  Created by Andrew Fedoniouk on 2015-09-11.
//  Copyright (c) 2015 andrew fedoniouk. All rights reserved.
//

#ifndef sciter_stdafx_h
#define sciter_stdafx_h

// empty

#endif

// DropFileArray.cpp: implementation of the CWinManArray class.
//
// (C) 2001 Reetcom / <VolkerBartheld@reetcom.de>
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DropFileArray.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDropFileArray::CDropFileArray()
{

}

CDropFileArray::~CDropFileArray()
{

}

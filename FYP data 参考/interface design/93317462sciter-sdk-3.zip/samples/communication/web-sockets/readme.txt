To run the server:

1. Install node.js from http://nodejs.org
2. CD to the "node.js" sub-folder and run "npm install" there. 
3. Type "node server.js" in that floder to start the server.

4. Open "/client/client.htm" in Sciter, it shall connect to the server automatically.
